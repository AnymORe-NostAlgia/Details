#include"elevator.h" 
CDate::CDate()    //��ʼ�� 
{ 
 time_t now;  
 ::time(&now); 
  
 struct tm *t_now;  
 t_now = localtime(&now); 
 
 y = t_now -> tm_year + 1900;  
 m = t_now -> tm_mon + 1;  
 d = t_now -> tm_mday; 
}  
string CDate::format(string df) 
{ 
  char c_df[20]; 
  if(df == df_s)  
  { 
   sprintf(c_df, "%d-%d-%d", y, m, d); 
   return string(c_df); 
  } 
  if(df == df_l)  
  { 
   sprintf(c_df, "%d ��%d ��%d ��", y, m, d); 
   return string(c_df); 
  } 
  return string(""); 
} 
const string CDate::df_s = "ddd"; 
const string CDate::df_l = "DDD"; 
Elevator::Elevator() 
{ 
 number3=1; 
} 
void Elevator::Showx() 
{ 
 cout<<"�õ���һ��ʮ��"<<"��ǰ������"<<number3<<"¥\n"<<endl; 
 cout<<"-----��ѡ�����-----"<<endl; 
 cout<<"|***  1.����    ***|"<<endl; 
 cout<<"|***  2.�½�    ***|"<<endl; 
 cout<<"|***  3.�˳�    ***|"<<endl; 
 cout<<"____________________"<<endl; 
} 
void Elevator::Choice() 
{ 
 int x, y; 
 cin>>x; 
 switch(x){ 
     case 1: 
   cout<<"������Ҫ�����¥����\n"<<endl; 
   cin>>y; 
   Elevator::Up_Doc(y); 
   break; 
  case 2: 
   cout<<"������Ҫ�����¥����\n"<<endl; 
   cin>>y; 
   Elevator:: Down_Doc(y); 
   break; 
  case 3: 
   break; 
  default: 
   cout<<"���ѡ�����󣬲��ܲ���\n"<<endl; 
   Elevator::Showx(); 
   break; 
 } 
} 
void Elevator::Up_Doc(int n) 
{ 
 int n3; 
 n3=number3; 
 number2=n; 
 if(number2>number3){ 
  for(i=0;i<=(number2-number3);i++){ 
   cout<<"--"<<number3+i<<"--"<<endl; 
   n3++; 
  } 
  number3=number2; 
  cout<<"��"<<number2<<"�㵽��"<<endl; 
 } 
} 
 void Elevator::Down_Doc(int n) 
{ 
 int n3; 
 n3=number3; 
 number2=n; 
 if(number2<number3){ 
  for(i=0;i<=(number3-number2);i++){ 
   cout<<"--"<<number3-i<<"--"<<endl; 
      n3++; 
  } 
    number3=number2; 
 cout<<"��"<<number2<<"�㵽��"<<endl; 
 } 
 } 
 void Person::Cin(){ 
 cin>>nowfloor>>desfloor; 
 n_floor=nowfloor; 
 d_floor=desfloor; 
 } 
 void AdvancedElevator::Showy_out() 
 { 
  int i; 
  Showx(); 
  cout<<"��ѡ�������"<<endl; 
  cin>>xx; 
  cout<<"        "<<endl; 
  cout<<"�˿�����Ϊ��"<<endl; 
  cin>>num_person; 
  for(i=1;i<=num_person;i++){ 
   Cin(); 
   per[2*i-1]=n_floor; 
   per[2*i-2]=d_floor; 
  } 
  Sort(); 
  if(xx==1){ 
  for(i=0;i<num_person;i++){ 
   Up_Doc(per[i]); 
  } 
 Showy_out(); 
  } 
 if(xx=2){ 
  for(i=0;i<num_person;i++){ 
   Down_Doc(per[num_person-1-i]); 
   cout<<"��"<<per[num_person-1-i]<<"����"<<endl; 
  } 
  Showy_out(); 
 } 
 } 
 void AdvancedElevator::Sort() 
 { 
  int i,j,k,temp,min; 
  for(i=k=1;i<2*num_person;i++){ 
   for(j=0;j<k;j++){ 
    if(per[j]==per[i]) 
     break; 
   } 
   if(j==k){ 
    per[k]=per[j]; 
    k++; 
   } 
  } 
  num_person=k; 
  for(i=0;i<num_person;i++){ 
   min=i; 
   for(j=i+1;j<num_person;j++){ 
    if(per[min]>per[j]) 
     min=j; 
    temp=per[min]; 
    per[min]=per[i]; 
    per[i]=temp; 
   } 
  } 
 }