#include <iostream>
#include<ctime>
#include<cstdlib>
#include<string>
#include<cstdio> 
using namespace std;
class CDate
 {
	 int d,m,y; 
	 static const string df_s; 
	 static const string df_l;
 public: 
	 CDate();
     string format(string); 
 };
 class Elevator{
 protected:
	 int i;
	 int number2;
	 int number3; 
public:  
	Elevator();  
	void Showx();
	void Choice();  
	void Up_Doc(int n);
	void Down_Doc(int n);
 };
 class Person{
 private:
	 int nowfloor;
	 int desfloor; 
 protected:  
	 int n_floor;
	 int d_floor; 
 public:
	 void Cin();
 };
 class AdvancedElevator:public Elevator,public Person 
 {
 private:
	 int xx;
	 int num_person;
	 int a[20];  
	 int b[20];
	 int per[10];
 public:  
	 void Showy_out();
	 void Sort(); 
};
