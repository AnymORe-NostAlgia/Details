#include"elevator.h" 
int main(void) 
{ 
 CDate now; 
 AdvancedElevator Elevator1; 
 cout << now.format("DDD") <<endl; 
 Elevator1.Showy_out(); 
} 
