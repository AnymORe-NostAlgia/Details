#include<iostream>
using namespace std;
double power(double m,int n=2)
{
    double temp=m;
    for(int i=2;i<=n;++i)
        temp*=m;
    return temp;
}
int power(int m,int n=2)
{
    int temp=m;
    for(int i=2;i<=n;++i)
        temp*=m;
    return temp;
}
int main()
{
    cout<<power(5)<<endl;
    cout<<power(1.2)<<endl;
    return 0;
}
