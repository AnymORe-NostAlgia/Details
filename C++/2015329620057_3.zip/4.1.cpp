#include<iostream>
using namespace std;
int fun(int n)
{
    return n;
}
float fun(float n)
{
    return n;
}



int main()
{
    int n=1;
    float m=10.23;
    cout<<fun(n)<<' ';
    cout<<fun(m)<<' ';

}
