#include<iostream>
using namespace std;
void display(int const const1=5)
{
    int const const2=5;
    int array1[const1];
    int array2[const2];
    for(int i=0;i<5;++i)
        {
            array1[i]=i;
            array2[i]=i*10;
        cout<<array1[i]<<' '<<array2[i]<<' ';
        }
}
int main()
{
    display(5);
    return 0;

}
