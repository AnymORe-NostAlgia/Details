#include<iostream>
using namespace std;
double power(double m,int n=2)
{
    double temp=m;
    for(int i=2;i<=n;++i)
        temp*=m;
    return temp;
}

int main()
{
    double m;
    int n;
    cin>>m>>n;
    cout<<power(m,n);
    return 0;
}
