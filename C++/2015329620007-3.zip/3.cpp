#include<iostream>
using namespace std;
double f(int a=10,int b=20,int c=5)
{
    return a*b*c;
}
int main()
{
    cout<<f()<<endl<<f(20)<<endl<<f(10,5)<<endl<<f(10,10,10)<<endl;
    return 0;
}

