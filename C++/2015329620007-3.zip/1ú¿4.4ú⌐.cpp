#include<iostream>
#include<cstring>
using namespace std;
#define maxn 200
void display(int **(&arr),int row,int col)
{
    for(int i=0; i<row; ++i)
        for(int j=0; j<col; ++j)
            cout<<arr[i][j];
}
int main()
{
    int row,col;
    cin>>row>>col;
    int **arr;
    *arr=new int[row];

    //allocate memory to
    for (int i = 0 ; i< col ; ++i)
        *(arr+i) = new int[col];

    for(int i=0; i<row; ++i)
        for(int j=0; j<col; ++j)
            arr[i][j]=1;

    display(arr,row,col);

    for (int i =0 ; i < col ; i ++)
        delete []arr[i];
    delete []arr;

    return 0;
}
