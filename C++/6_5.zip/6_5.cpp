#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
class books
{
	string publisher;
	int stock;
	float price;
	void require(books* ,int);
public:
	string author;
	string title;
	static int count1;
	static int count0;
	books()
	{
		price=0;
		stock=0;
		author= "";
		title= "";
		publisher="";
		count1=0;
		count0=0;
	}
	void display();
	void request();
	void input();
	friend int research(books* ,int);
	friend void FBU(books*, int);
};
int books::count1;
int books::count0;
void books::display()
{
	cout<<"author: "<<author<<endl;
	cout<<"title: "<<title<<endl;
	cout<<"price: "<<price<<endl;
	cout<<"publisher: "<<publisher<<endl;
	cout<<"stock position: "<<stock<<endl;
}
void books::request()
{
	int n;
	cout<<"input the number of the books you need"<<endl;
	cin>>n;
	if(n<=stock)
	{
		cout<<"the total cost is "<<n*price<<endl;
		stock-=n;
	}
	else
		cout<<"Required copies not in stock\n";
}
void books::input()
{
	cout<<"input the author's name\n";
	cin>>author;
	cout<<"input the title\n";
	cin>>title;
	cout<<"input the price\n";
	cin>>price;
	cout<<"input the publisher\n";
	cin>>publisher;
	cout<<"input the stock position\n";
	cin>>stock;
}

int research(books A[],int n)
{
	string namea="";
	string nameb="";
	cout<<"input the auther's name\n";
	cin>>namea;
	cout<<"input the book's name\n";
	cin>>nameb;
	int i,m=0;
	for(i=0;i<n;i++)
	{
		if(A[i].author==namea && A[i].title==nameb)
		{
			m=1;
			A->count1++;//access members with pointer
			A[i].display();
			break;
		}
	}
	if(m==0)
	{
		cout<<"sorry!there is no such book.\n";
		i=-1;
		A->count0++;//access member with pointer
	}
	return i;
}
void books::require(books A[],int n)
{
	int i;
	i=research(A,n);
	cout<<"input the new price\n";
	cin>>A[i].price;
	A[i].display();
}
void FBU(books A[],int n)
{
	char choice;
	int i;
	while(1)
	{
		cout<<"want to search and buy?(y/n)\n";
		cin>>choice;
		if(choice=='n')
			break;
		i=research(A,n);
		if(i!=-1)
			A[i].request();
	}
	while(1)
	{
		cout<<"want to update the price of books?(y/n)\n";
		cin>>choice;
		if(choice=='n')
			break;
		A[i].require(A,n);
	}
	cout<<"cuccessed research: "<<A->count1<<endl;//access member with pointer
	cout<<"failed research: "<<A->count0<<endl;//access member with pointer
}
void main()
{
	int n,i;
	char choice;
	cout<<"*******first input the information of books********\n";
	cout<<"input the number of books\n";
	cin>>n;
	books *Boook;
	Boook =new books[n];
	for(i=0;i<n;i++)
	{
		Boook[i].input();
	}
	cout<<"********now you can search for books and buy********\n";
	while(1)
	{
		FBU(Boook,n);
		cout<<"want to continue?(y/n)\n";
		cin>>choice;
		if(choice=='n')
			break;
	}
}
