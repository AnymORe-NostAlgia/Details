#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
class books
{
	string publisher;
	float price;
	int stock;
public:
	string author;
	string title;
	books()
	{
		price=0;
		stock=0;
		author= "";
		title= "";
		publisher="";
	}
	void display();
	void request();
	void input();
};
void books::display()
{
	cout<<"author: "<<author<<endl;
	cout<<"title: "<<title<<endl;
	cout<<"price: "<<price<<endl;
	cout<<"publisher: "<<publisher<<endl;
	cout<<"stock position: "<<stock<<endl;
}
void books::request()
{
	int n;
	cout<<"input the number of the books you need"<<endl;
	cin>>n;
	if(n<=stock)
	{
		cout<<"the total cost is "<<n*price<<endl;
		stock-=n;
	}
	else
		cout<<"Required copies not in stock\n";
}
void books::input()
{
	cout<<"input the author's name\n";
	cin>>author;
	cout<<"input the title\n";
	cin>>title;
	cout<<"input the price\n";
	cin>>price;
	cout<<"input the publisher\n";
	cin>>publisher;
	cout<<"input the stock position\n";
	cin>>stock;
}
void main()
{
	int n,i,m=0;
	int result1,result2;
	cout<<"input the number of books\n";
	cin>>n;
	books *Boook;
	Boook =new books[n];
	for(i=0;i<n;i++)
	{
		Boook[i].input();
	}
	
	string namea="";
	string nameb="";
	cout<<"input the auther's name\n";
	cin>>namea;
	cout<<"input the book's name\n";
	cin>>nameb;
	for(i=0;i<n;i++)
	{
		if(Boook[i].author==namea)
		{
			Boook[i].display();
			Boook[i].request();
			m=1;
			break;
		}
	}
	if(m=0)
		cout<<"sorry!there is no such book.\n";
	
}
